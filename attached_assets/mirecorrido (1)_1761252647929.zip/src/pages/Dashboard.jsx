import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { Trophy, Target, Star, TrendingUp, Sparkles, Zap } from 'lucide-react';

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: challenges = [] } = useQuery({
    queryKey: ['challenges'],
    queryFn: () => base44.entities.Challenge.list(),
    initialData: [],
  });

  const { data: achievements = [] } = useQuery({
    queryKey: ['achievements'],
    queryFn: () => base44.entities.Achievement.list(),
    initialData: [],
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: () => base44.entities.UserProgress.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const completedChallenges = userProgress.filter(p => p.type === 'challenge' && p.completed).length;
  const earnedAchievements = userProgress.filter(p => p.type === 'achievement' && p.completed).length;
  
  const currentLevel = user?.level || 1;
  const currentXP = user?.total_xp || 0;
  const xpForNextLevel = currentLevel * 1000;
  const xpProgress = ((currentXP % 1000) / 1000) * 100;
  const saldo = user?.total_xp || 0;

  // Detectar si se debe mostrar confetti
  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!prefersReducedMotion && currentLevel > 1) {
      const hasSeenConfetti = sessionStorage.getItem(`confetti_level_${currentLevel}`);
      if (!hasSeenConfetti) {
        setShowConfetti(true);
        sessionStorage.setItem(`confetti_level_${currentLevel}`, 'true');
        setTimeout(() => setShowConfetti(false), 3000);
      }
    }
  }, [currentLevel]);

  if (!user) {
    return (
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <div className="space-y-4">
          <div className="h-40 bg-gray-200 rounded-2xl animate-pulse" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl animate-pulse" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      {/* Confetti Effect */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-50" aria-hidden="true">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              style={{
                position: 'fixed',
                left: `${Math.random() * 100}%`,
                top: `-10px`,
                width: '10px',
                height: '10px',
                backgroundColor: ['#7c3aed', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#ec4899'][Math.floor(Math.random() * 6)],
                animation: `confetti-fall 3s linear ${Math.random()}s`,
                zIndex: 1000
              }}
            />
          ))}
        </div>
      )}

      {/* Bienvenida */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-6 md:p-8 text-white shadow-xl mb-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <span className="text-2xl font-bold">{currentLevel}</span>
          </div>
          <div className="flex-1">
            <h2 className="text-2xl md:text-3xl font-bold mb-1">¡Hola, {user.full_name}!</h2>
            <p className="text-purple-100">Nivel {currentLevel} · {currentXP.toLocaleString()} XP</p>
          </div>
          <Sparkles className="w-8 h-8 text-yellow-300 hidden md:block" aria-hidden="true" />
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progreso al nivel {currentLevel + 1}</span>
            <span>{Math.floor(xpProgress)}%</span>
          </div>
          <div className="h-3 bg-white/20 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-yellow-300 to-orange-400 rounded-full transition-all duration-1000"
              style={{width: `${xpProgress}%`}}
              role="progressbar"
              aria-valuenow={Math.floor(xpProgress)}
              aria-valuemin="0"
              aria-valuemax="100"
              aria-label={`Progreso al siguiente nivel: ${Math.floor(xpProgress)}%`}
            />
          </div>
          <p className="text-sm text-purple-100">{xpForNextLevel - currentXP} XP para el siguiente nivel</p>
        </div>
      </div>

      {/* Métricas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-gray-600">Desafíos completados</h3>
            <Target className="w-5 h-5 text-purple-600" aria-hidden="true" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{completedChallenges}</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-gray-600">Puntos disponibles</h3>
            <Star className="w-5 h-5 text-yellow-500" aria-hidden="true" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{saldo.toLocaleString()}</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-gray-600">Logros</h3>
            <Trophy className="w-5 h-5 text-blue-600" aria-hidden="true" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{earnedAchievements}</p>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-6 border border-purple-200">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" aria-hidden="true" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-1">Completa 1 desafío para subir de nivel</h3>
              <p className="text-sm text-gray-600">Gana más XP y desbloquea recompensas</p>
            </div>
          </div>
          <Link to={createPageUrl('Challenges')}>
            <button className="px-6 py-3 bg-purple-600 text-white font-semibold rounded-xl hover:bg-purple-700 transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2">
              Ver desafíos
            </button>
          </Link>
        </div>
      </div>

      <style>{`
        @keyframes confetti-fall {
          0% { transform: translateY(-100px) rotate(0deg); opacity: 1; }
          100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }
      `}</style>
    </div>
  );
}