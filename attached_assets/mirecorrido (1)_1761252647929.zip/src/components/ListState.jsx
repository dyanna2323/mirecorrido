import React from 'react';
import { Loader2, AlertCircle, Inbox } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ListState({ isLoading, isError, isEmpty, children, onRetry, emptyMessage = 'No hay nada aquí todavía' }) {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 md:py-20" role="status" aria-live="polite">
        <Loader2 className="w-12 h-12 md:w-16 md:h-16 text-purple-500 animate-spin mb-4" />
        <p className="text-sm md:text-base text-gray-600 font-semibold">Cargando...</p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex flex-col items-center justify-center py-12 md:py-20" role="alert">
        <AlertCircle className="w-12 h-12 md:w-16 md:h-16 text-red-500 mb-4" />
        <p className="text-sm md:text-base text-gray-700 font-semibold mb-4">Algo salió mal</p>
        {onRetry && (
          <Button
            onClick={onRetry}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            Intentar de nuevo
          </Button>
        )}
      </div>
    );
  }

  if (isEmpty) {
    return (
      <div className="flex flex-col items-center justify-center py-12 md:py-20">
        <Inbox className="w-12 h-12 md:w-16 md:h-16 text-gray-400 mb-4" />
        <p className="text-sm md:text-base text-gray-600 font-semibold">{emptyMessage}</p>
      </div>
    );
  }

  return <>{children}</>;
}