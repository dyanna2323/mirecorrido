import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { ArrowLeft, Gift, Sparkles, Star, AlertCircle, Loader2 } from 'lucide-react';
import { useToast } from '../components/ToastContainer';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

export default function Rewards() {
  const [user, setUser] = useState(null);
  const [selectedReward, setSelectedReward] = useState(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const queryClient = useQueryClient();
  const { showToast } = useToast();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: rewards = [], isLoading } = useQuery({
    queryKey: ['rewards'],
    queryFn: () => base44.entities.Reward.list(),
    initialData: [],
  });

  const { data: userRewards = [] } = useQuery({
    queryKey: ['userRewards', user?.email],
    queryFn: () => base44.entities.UserReward.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const claimRewardMutation = useMutation({
    mutationFn: async (reward) => {
      const currentUser = await base44.auth.me();
      if (!currentUser) throw new Error("Usuario no autenticado");

      if (currentUser.total_xp < reward.points_required) {
        throw new Error("Saldo insuficiente");
      }
      
      const newXP = currentUser.total_xp - reward.points_required;
      await base44.auth.updateMe({ total_xp: newXP });
      await base44.entities.UserReward.create({
        user_email: currentUser.email,
        reward_id: reward.id,
        claimed: true,
        claimed_date: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userRewards'] });
      base44.auth.me().then(setUser);
      showToast('¡Recompensa canjeada! 🎉', 'success');
      setShowConfirmDialog(false);
      setSelectedReward(null);
    },
    onError: (error) => {
      showToast(error.message || 'Algo salió mal, inténtalo de nuevo', 'error');
      setShowConfirmDialog(false);
    },
  });

  const handleClaimClick = (reward) => {
    setSelectedReward(reward);
    setShowConfirmDialog(true);
  };

  const handleConfirmClaim = () => {
    if (selectedReward) {
      claimRewardMutation.mutate(selectedReward);
    }
  };

  const currentXP = user?.total_xp || 0;

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-80 bg-gray-200 rounded-xl animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        {/* Header */}
        <div className="mb-6">
          <Link to={createPageUrl('Dashboard')} className="inline-flex items-center gap-2 text-purple-600 hover:text-purple-800 mb-4 transition-colors font-semibold">
            <ArrowLeft className="w-5 h-5" />
            <span>Volver al Inicio</span>
          </Link>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Recompensas</h1>
              <p className="text-gray-600">Canjea tus puntos por premios increíbles</p>
            </div>
            <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-xl p-4 shadow-lg">
              <div className="text-3xl font-bold text-white">{currentXP.toLocaleString()}</div>
              <p className="text-sm text-white font-semibold">Puntos Disponibles</p>
            </div>
          </div>
        </div>

        {/* Rewards Grid */}
        {rewards.length === 0 ? (
          <div className="text-center py-12">
            <Gift className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-xl font-semibold text-gray-600">No hay recompensas disponibles</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {rewards.map((reward) => {
              const isClaimed = userRewards.some(ur => ur.reward_id === reward.id && ur.claimed);
              const canClaim = currentXP >= reward.points_required && !isClaimed;
              const insufficientFunds = currentXP < reward.points_required;

              return (
                <div 
                  key={reward.id}
                  className={`rounded-2xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl border-2 ${
                    isClaimed 
                      ? 'border-green-400 bg-green-50'
                      : canClaim
                      ? 'border-purple-400 bg-white hover:scale-105'
                      : 'border-gray-200 bg-gray-50'
                  }`}
                >
                  {reward.image_url && (
                    <div className="h-48 overflow-hidden">
                      <img 
                        src={reward.image_url} 
                        alt={reward.title}
                        className={`w-full h-full object-cover ${isClaimed ? '' : 'opacity-70'}`}
                      />
                    </div>
                  )}
                  
                  <div className="p-6">
                    <h3 className="font-bold text-gray-900 mb-2 text-lg">{reward.title}</h3>
                    <p className="text-sm text-gray-600 mb-4">{reward.description}</p>
                    
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Star className="w-5 h-5 text-yellow-500" />
                        <span className="text-xl font-bold text-purple-600">{reward.points_required}</span>
                      </div>
                      <span className="text-xs text-gray-500 capitalize">{reward.category}</span>
                    </div>

                    {!isClaimed && canClaim && (
                      <Button
                        onClick={() => handleClaimClick(reward)}
                        disabled={claimRewardMutation.isLoading}
                        className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        {claimRewardMutation.isLoading ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Canjeando...
                          </>
                        ) : (
                          <>
                            <Gift className="w-4 h-4 mr-2" />
                            Canjear Ahora
                          </>
                        )}
                      </Button>
                    )}

                    {!isClaimed && insufficientFunds && (
                      <div className="flex items-center gap-2 text-sm text-gray-500 bg-gray-100 rounded-lg p-3">
                        <AlertCircle className="w-4 h-4" />
                        <span>Necesitas {reward.points_required - currentXP} puntos más</span>
                      </div>
                    )}

                    {isClaimed && (
                      <div className="flex items-center justify-center gap-2 py-3 bg-green-100 rounded-lg border-2 border-green-400">
                        <Sparkles className="w-5 h-5 text-green-600" />
                        <span className="font-semibold text-green-600">¡Canjeado!</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar canje</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que quieres canjear "{selectedReward?.title}" por {selectedReward?.points_required} puntos?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleConfirmClaim}
              disabled={claimRewardMutation.isLoading}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {claimRewardMutation.isLoading ? 'Canjeando...' : 'Confirmar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}