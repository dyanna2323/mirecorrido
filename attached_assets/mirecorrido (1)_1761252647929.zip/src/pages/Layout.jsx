
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Sheet, SheetTrigger, SheetContent } from '@/components/ui/sheet';
import { Menu, Home, Trophy, Target, Gift, Users, Gamepad2, User } from 'lucide-react';
import { createPageUrl } from './utils';
import { ToastProvider } from './components/ToastContainer';

const NAV_ITEMS = [
  { to: 'Dashboard', label: 'Inicio', icon: Home },
  { to: 'Challenges', label: 'Desafíos', icon: Target },
  { to: 'Rewards', label: 'Premios', icon: Gift },
  { to: 'Leaderboard', label: 'Ranking', icon: Users },
  { to: 'Games', label: 'Juegos', icon: Gamepad2 },
  { to: 'Profile', label: 'Perfil', icon: User }
];

function MainNav({ onNavigate, isMobile }) {
  const location = useLocation();
  const currentPath = location.pathname.split('/').pop() || 'Dashboard';

  return (
    <nav className={`flex gap-2 ${isMobile ? 'flex-col' : 'flex-row flex-wrap'}`} aria-label="Navegación principal">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = currentPath === item.to || (currentPath === '' && item.to === 'Dashboard');
        
        return (
          <Link
            key={item.to}
            to={createPageUrl(item.to)}
            onClick={() => onNavigate?.()}
            aria-current={isActive ? 'page' : undefined}
            className={`rounded-xl md:rounded-2xl px-4 py-2.5 text-sm font-bold transition-all duration-300 flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 ${
              isActive
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg scale-105'
                : 'bg-white/80 hover:bg-white text-gray-700 hover:scale-105 border-2 border-purple-200'
            }`}
          >
            <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span className={isMobile ? '' : 'hidden sm:inline'}>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

export default function Layout({ children }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <ToastProvider>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fredoka:wght@300;400;500;600;700&display=swap');
        
        * {
          box-sizing: border-box;
        }
        
        body {
          font-family: 'Fredoka', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        @media (prefers-reduced-motion: reduce) {
          *, *::before, *::after {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
            scroll-behavior: auto !important;
          }
        }
        
        .skip-link {
          position: absolute;
          top: -40px;
          left: 0;
          background: #7c3aed;
          color: white;
          padding: 8px 16px;
          text-decoration: none;
          border-radius: 0 0 8px 0;
          font-weight: bold;
          z-index: 100;
        }
        
        .skip-link:focus {
          top: 0;
          outline: 3px solid #fbbf24;
        }
        
        @keyframes bounce-fun {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        
        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 20px rgba(168, 85, 247, 0.4); }
          50% { box-shadow: 0 0 30px rgba(168, 85, 247, 0.6); }
        }
        
        @keyframes rainbow-pulse {
          0%, 100% { box-shadow: 0 0 20px rgba(168, 85, 247, 0.5); }
          25% { box-shadow: 0 0 30px rgba(236, 72, 153, 0.5); }
          50% { box-shadow: 0 0 20px rgba(59, 130, 246, 0.5); }
          75% { box-shadow: 0 0 30px rgba(236, 72, 153, 0.5); }
        }
        
        @keyframes slide-up {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        
        @keyframes confetti-fall {
          0% { transform: translateY(-100px) rotate(0deg); opacity: 1; }
          100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }
        
        .animate-bounce-fun { animation: bounce-fun 1s ease-in-out infinite; }
        .animate-pulse-glow { animation: pulse-glow 2s ease-in-out infinite; }
        .animate-rainbow-pulse { animation: rainbow-pulse 3s ease-in-out infinite; }
        .animate-slide-up { animation: slide-up 0.3s ease-out; }
        .animate-float { animation: float 3s ease-in-out infinite; }
      `}</style>

      <div className="min-h-screen bg-gradient-to-br from-pink-300 via-purple-300 to-blue-300">
        <a href="#main" className="skip-link">
          Saltar al contenido
        </a>

        <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-xl border-b-4 border-purple-400 shadow-lg">
          <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-3 md:py-4">
            <div className="flex items-center justify-between gap-3 mb-3 md:mb-4">
              <div className="flex items-center gap-2 md:gap-3">
                <div className="p-2 md:p-3 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl md:rounded-2xl shadow-lg animate-float">
                  <Trophy className="w-6 h-6 md:w-8 md:h-8 text-white" aria-hidden="true" />
                </div>
                <div>
                  <h1 className="text-lg sm:text-xl md:text-2xl font-bold text-purple-700">Mi Aventura ✨</h1>
                  <p className="text-xs text-gray-600 hidden sm:block">¡Tu viaje comienza aquí!</p>
                </div>
              </div>

              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger 
                  className="lg:hidden inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 font-bold hover:from-purple-600 hover:to-pink-600 transition-all duration-300 shadow-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"
                  aria-label="Abrir menú de navegación"
                >
                  <Menu className="w-5 h-5" aria-hidden="true" />
                  <span className="hidden xs:inline">Menú</span>
                </SheetTrigger>
                <SheetContent side="left" className="w-[280px] bg-gradient-to-b from-purple-100 to-pink-100">
                  <div className="mt-8">
                    <MainNav onNavigate={() => setMobileMenuOpen(false)} isMobile={true} />
                  </div>
                </SheetContent>
              </Sheet>
            </div>

            <div className="hidden lg:block">
              <MainNav isMobile={false} />
            </div>
          </div>
        </header>

        <main id="main" className="relative z-10 min-h-[calc(100vh-200px)]">
          {children}
        </main>

        <footer className="bg-white/90 backdrop-blur-xl border-t-4 border-purple-400 mt-12 shadow-lg" role="contentinfo">
          <div className="max-w-7xl mx-auto px-4 py-6 text-center">
            <p className="text-sm text-gray-600 font-semibold">
              © {new Date().getFullYear()} Mi Aventura - ¡Tu camino al éxito! 🌟
            </p>
          </div>
        </footer>
      </div>
    </ToastProvider>
  );
}
