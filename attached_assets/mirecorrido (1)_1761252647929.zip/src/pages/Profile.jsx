import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { ArrowLeft, Edit2, Loader2, LogOut, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '../components/ToastContainer';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function Profile() {
  const [user, setUser] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    bio: '',
    avatar_url: ''
  });
  const [errors, setErrors] = useState({});
  const queryClient = useQueryClient();
  const { showToast } = useToast();

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setFormData({
        full_name: u.full_name || '',
        bio: u.bio || '',
        avatar_url: u.avatar_url || ''
      });
    }).catch(() => {});
  }, []);

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      await base44.auth.updateMe(data);
    },
    onSuccess: () => {
      base44.auth.me().then(setUser);
      setIsEditing(false);
      setErrors({});
      queryClient.invalidateQueries();
      showToast('¡Listo! Cambios guardados', 'success');
    },
    onError: (error) => {
      showToast(error.message || 'Algo salió mal, inténtalo de nuevo', 'error');
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validación
    const newErrors = {};
    if (!formData.full_name || formData.full_name.trim().length === 0) {
      newErrors.full_name = 'El nombre es requerido';
    } else if (formData.full_name.length < 2) {
      newErrors.full_name = 'El nombre debe tener al menos 2 caracteres';
    }

    if (formData.bio && formData.bio.length > 160) {
      newErrors.bio = 'La biografía no puede exceder 160 caracteres';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    updateMutation.mutate(formData);
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-purple-500 animate-spin" />
      </div>
    );
  }

  const currentLevel = user.level || 1;
  const currentXP = user.total_xp || 0;
  const xpProgress = ((currentXP % 1000) / 1000) * 100;

  return (
    <>
      <div className="max-w-4xl mx-auto p-4 md:p-8">
        <Link to={createPageUrl('Dashboard')} className="inline-flex items-center gap-2 text-purple-600 hover:text-purple-800 mb-6 transition-colors font-semibold">
          <ArrowLeft className="w-5 h-5" />
          <span>Volver al Inicio</span>
        </Link>

        <h1 className="text-3xl font-bold text-gray-900 mb-8">Mi Perfil</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Stats Card */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
              <div className="text-center mb-6">
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-4xl">{currentLevel}</span>
                </div>
                <h2 className="text-xl font-bold text-gray-900 mb-1">{user.full_name}</h2>
                <p className="text-sm text-gray-600">{user.email}</p>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2 text-sm">
                    <span className="text-gray-700 font-medium">Progreso de Nivel</span>
                    <span className="text-gray-600">{Math.floor(xpProgress)}%</span>
                  </div>
                  <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-1000"
                      style={{width: `${xpProgress}%`}}
                      role="progressbar"
                      aria-valuenow={Math.floor(xpProgress)}
                      aria-valuemin="0"
                      aria-valuemax="100"
                      aria-label="Progreso de nivel"
                    />
                  </div>
                  <p className="text-xs text-gray-600 mt-2">{currentXP.toLocaleString()} / {(currentLevel * 1000).toLocaleString()} XP</p>
                </div>

                <div className="pt-4 border-t border-gray-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">XP Total</span>
                    <span className="text-xl font-bold text-yellow-600">{currentXP.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Nivel Actual</span>
                    <span className="text-xl font-bold text-purple-600">{currentLevel}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Profile Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Detalles del Perfil</h3>
                <Button
                  onClick={() => setIsEditing(!isEditing)}
                  variant="outline"
                  size="icon"
                  aria-label={isEditing ? 'Cancelar edición' : 'Editar perfil'}
                >
                  <Edit2 className="w-5 h-5" />
                </Button>
              </div>

              {!isEditing ? (
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-600 mb-1 block font-medium">Nombre</label>
                    <p className="text-base text-gray-900">{user.full_name}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-600 mb-1 block font-medium">Biografía</label>
                    <p className="text-base text-gray-900 whitespace-pre-wrap">{user.bio || 'No hay biografía aún'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-600 mb-1 block font-medium">URL de Avatar</label>
                    <p className="text-base text-gray-900 break-all">{user.avatar_url || 'No definido'}</p>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                  <div>
                    <label htmlFor="full_name" className="text-sm text-gray-700 mb-2 block font-medium">
                      Nombre <span className="text-red-500">*</span>
                    </label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => {
                        setFormData({...formData, full_name: e.target.value});
                        if (errors.full_name) setErrors({...errors, full_name: ''});
                      }}
                      className={errors.full_name ? 'border-red-500' : ''}
                      required
                      aria-invalid={!!errors.full_name}
                      aria-describedby={errors.full_name ? 'full_name_error' : undefined}
                    />
                    {errors.full_name && (
                      <p id="full_name_error" className="text-sm text-red-600 mt-1">{errors.full_name}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="bio" className="text-sm text-gray-700 mb-2 block font-medium">Biografía</label>
                    <Textarea
                      id="bio"
                      value={formData.bio}
                      onChange={(e) => {
                        setFormData({...formData, bio: e.target.value});
                        if (errors.bio) setErrors({...errors, bio: ''});
                      }}
                      rows="4"
                      maxLength="160"
                      placeholder="Cuéntanos sobre ti..."
                      className={errors.bio ? 'border-red-500' : ''}
                      aria-invalid={!!errors.bio}
                      aria-describedby="bio_helper"
                    />
                    <p id="bio_helper" className={`text-xs mt-1 ${errors.bio ? 'text-red-600' : 'text-gray-500'}`}>
                      {errors.bio || `${formData.bio.length}/160 caracteres`}
                    </p>
                  </div>

                  <div>
                    <label htmlFor="avatar_url" className="text-sm text-gray-700 mb-2 block font-medium">URL de Avatar</label>
                    <Input
                      id="avatar_url"
                      type="url"
                      value={formData.avatar_url}
                      onChange={(e) => setFormData({...formData, avatar_url: e.target.value})}
                      placeholder="https://ejemplo.com/avatar.jpg"
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-4">
                    <Button
                      type="submit"
                      disabled={updateMutation.isLoading}
                      className="flex-1 bg-purple-600 hover:bg-purple-700"
                    >
                      {updateMutation.isLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Guardando...
                        </>
                      ) : (
                        'Guardar Cambios'
                      )}
                    </Button>
                    <Button
                      type="button"
                      onClick={() => {
                        setIsEditing(false);
                        setErrors({});
                        setFormData({
                          full_name: user.full_name || '',
                          bio: user.bio || '',
                          avatar_url: user.avatar_url || ''
                        });
                      }}
                      variant="outline"
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              )}
            </div>

            {/* Account Actions */}
            <div className="mt-6 space-y-3">
              <Button
                onClick={() => setShowLogoutDialog(true)}
                variant="outline"
                className="w-full justify-start text-gray-700 hover:bg-gray-100"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Cerrar sesión
              </Button>
              
              <Button
                onClick={() => setShowDeleteDialog(true)}
                variant="outline"
                className="w-full justify-start text-red-600 hover:bg-red-50 border-red-200"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Eliminar cuenta
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Logout Dialog */}
      <Dialog open={showLogoutDialog} onOpenChange={setShowLogoutDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cerrar sesión</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que quieres cerrar sesión?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLogoutDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleLogout} className="bg-purple-600 hover:bg-purple-700">
              Cerrar sesión
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Account Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Eliminar cuenta</DialogTitle>
            <DialogDescription>
              Esta acción es permanente y no se puede deshacer. ¿Estás completamente seguro?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={() => {
                showToast('Función no implementada', 'info');
                setShowDeleteDialog(false);
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              Eliminar cuenta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}