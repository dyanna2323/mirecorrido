import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Target, CheckCircle, Loader2, Lock, Star, Zap, Sparkles, Trophy, Gift } from 'lucide-react';
import { useToast } from '../components/ToastContainer';

export default function Challenges() {
  const [user, setUser] = useState(null);
  const [completingId, setCompletingId] = useState(null);
  const queryClient = useQueryClient();
  const { showToast } = useToast();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: challenges = [], isLoading } = useQuery({
    queryKey: ['challenges'],
    queryFn: async () => {
      const allChallenges = await base44.entities.Challenge.list('order');
      return allChallenges;
    },
    initialData: [],
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: () => base44.entities.UserProgress.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const completeMutation = useMutation({
    mutationFn: async (challengeId) => {
      const progress = userProgress.find(p => p.achievement_id === challengeId && p.type === 'challenge');
      
      if (progress?.completed) {
        throw new Error('Ya completaste este desafío');
      }

      const challenge = challenges.find(c => c.id === challengeId);
      
      if (progress) {
        await base44.entities.UserProgress.update(progress.id, {
          completed: true,
          progress_percentage: 100,
          completed_date: new Date().toISOString()
        });
      } else {
        await base44.entities.UserProgress.create({
          user_email: user.email,
          achievement_id: challengeId,
          type: 'challenge',
          completed: true,
          progress_percentage: 100,
          completed_date: new Date().toISOString()
        });
      }
      
      await base44.entities.ChallengeLog.create({
        user_email: user.email,
        challenge_id: challengeId,
        date: new Date().toISOString().split('T')[0],
        points_earned: challenge.points
      });
      
      const newXP = (user.total_xp || 0) + challenge.xp_reward;
      const newGumLeaves = (user.gum_leaves || 0) + challenge.points;
      const newLevel = Math.floor(newXP / 1000) + 1;
      await base44.auth.updateMe({ total_xp: newXP, gum_leaves: newGumLeaves, level: newLevel });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userProgress'] });
      base44.auth.me().then(setUser);
      showToast('¡Desafío completado! 🎉', 'success');
      setCompletingId(null);
    },
    onError: (error) => {
      showToast(error.message || 'Algo salió mal', 'error');
      setCompletingId(null);
    },
  });

  const handleComplete = (challengeId) => {
    setCompletingId(challengeId);
    completeMutation.mutate(challengeId);
  };

  const currentLevel = user?.level || 1;
  const availableChallenges = challenges.filter(c => c.level_required <= currentLevel);
  const lockedChallenges = challenges.filter(c => c.level_required > currentLevel);
  const completedCount = userProgress.filter(p => p.completed).length;

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto p-4 md:p-8">
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-40 bg-gradient-to-r from-purple-200 to-pink-200 rounded-2xl animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8">
      <style>{`
        @keyframes bounce-star {
          0%, 100% { transform: translateY(0) scale(1); }
          50% { transform: translateY(-10px) scale(1.2); }
        }
        @keyframes shimmer {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }
        @keyframes float-up {
          0% { transform: translateY(0) rotate(0deg); opacity: 1; }
          100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }
        }
        @keyframes pulse-ring {
          0% { transform: scale(0.8); opacity: 1; }
          100% { transform: scale(1.4); opacity: 0; }
        }
        .animate-bounce-star { animation: bounce-star 1s ease-in-out infinite; }
        .animate-shimmer {
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
          background-size: 1000px 100%;
          animation: shimmer 2s infinite;
        }
        .animate-float-up { animation: float-up 2s ease-out forwards; }
        .animate-pulse-ring { animation: pulse-ring 1s ease-out infinite; }
      `}</style>

      {/* Hero Banner */}
      <div className="relative mb-8 overflow-hidden rounded-3xl bg-gradient-to-r from-purple-600 via-pink-500 to-orange-400 p-8 md:p-12 shadow-2xl">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 w-20 h-20 bg-white rounded-full animate-bounce-star" />
          <div className="absolute top-20 right-20 w-16 h-16 bg-yellow-300 rounded-full animate-bounce-star" style={{animationDelay: '0.3s'}} />
          <div className="absolute bottom-10 left-1/3 w-12 h-12 bg-blue-300 rounded-full animate-bounce-star" style={{animationDelay: '0.6s'}} />
        </div>
        
        <div className="relative z-10 flex items-center gap-6">
          <div className="p-6 bg-white/20 backdrop-blur-xl rounded-3xl border-4 border-white/40 animate-pulse-ring">
            <Target className="w-16 h-16 text-white" />
          </div>
          <div className="flex-1">
            <h1 className="text-4xl md:text-5xl font-black text-white mb-3 drop-shadow-lg">
              ¡Mis Desafíos Mágicos! ✨
            </h1>
            <p className="text-xl text-white/90 font-semibold drop-shadow">
              Completa misiones y gana estrellas 🌟
            </p>
          </div>
          <div className="hidden md:block">
            <Sparkles className="w-20 h-20 text-yellow-300 animate-bounce-star" />
          </div>
        </div>
      </div>

      {/* Stats Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-gradient-to-br from-blue-500 to-cyan-400 rounded-2xl p-6 text-white shadow-xl transform hover:scale-105 transition-all">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold opacity-90">Nivel Actual</p>
              <p className="text-5xl font-black">{currentLevel}</p>
            </div>
            <Trophy className="w-16 h-16 opacity-80" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-xl transform hover:scale-105 transition-all">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold opacity-90">Completados</p>
              <p className="text-5xl font-black">{completedCount}/{challenges.length}</p>
            </div>
            <CheckCircle className="w-16 h-16 opacity-80" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-yellow-400 to-orange-400 rounded-2xl p-6 text-white shadow-xl transform hover:scale-105 transition-all">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold opacity-90">Hojas 🍃</p>
              <p className="text-5xl font-black">{user?.gum_leaves || 0}</p>
            </div>
            <Gift className="w-16 h-16 opacity-80" />
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white rounded-2xl p-6 shadow-xl border-4 border-purple-200 mb-8">
        <div className="flex items-center justify-between mb-4">
          <span className="text-lg font-bold text-gray-800">Tu Aventura</span>
          <span className="text-2xl font-black text-purple-600">{Math.floor((completedCount / challenges.length) * 100)}%</span>
        </div>
        <div className="relative h-8 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full overflow-hidden border-2 border-purple-300">
          <div 
            className="absolute inset-0 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-400 rounded-full transition-all duration-1000 flex items-center justify-end pr-2"
            style={{width: `${(completedCount / challenges.length) * 100}%`}}
          >
            <Sparkles className="w-6 h-6 text-white animate-bounce-star" />
          </div>
        </div>
      </div>

      {/* Available Challenges */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-6">
          <Zap className="w-8 h-8 text-yellow-500 animate-bounce-star" />
          <h2 className="text-3xl font-black text-gray-900">¡A Jugar!</h2>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {availableChallenges.map((challenge) => {
            const progress = userProgress.find(p => p.achievement_id === challenge.id && p.type === 'challenge');
            const isCompleted = progress?.completed;
            const isLoading = completingId === challenge.id;

            return (
              <div
                key={challenge.id}
                className={`group relative rounded-3xl overflow-hidden shadow-2xl transform transition-all duration-500 hover:scale-105 border-4 ${
                  isCompleted 
                    ? 'border-green-400 bg-gradient-to-br from-green-50 to-emerald-50' 
                    : 'border-purple-300 bg-white hover:border-purple-500'
                }`}
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={challenge.image_url}
                    alt={challenge.title}
                    className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 ${
                      isCompleted ? 'opacity-80' : ''
                    }`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  
                  {/* Order Badge */}
                  <div className="absolute top-4 left-4 w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-3xl font-black text-white shadow-xl border-4 border-white animate-pulse-ring">
                    {challenge.order}
                  </div>

                  {/* Stars */}
                  <div className="absolute top-4 right-4 flex gap-1">
                    {[...Array(challenge.difficulty)].map((_, i) => (
                      <Star 
                        key={i} 
                        className="w-6 h-6 fill-yellow-400 text-yellow-400 drop-shadow-lg animate-bounce-star" 
                        style={{animationDelay: `${i * 0.1}s`}}
                      />
                    ))}
                  </div>

                  {isCompleted && (
                    <div className="absolute inset-0 flex items-center justify-center bg-green-500/30 backdrop-blur-sm">
                      <div className="bg-white rounded-full p-4 shadow-2xl">
                        <CheckCircle className="w-16 h-16 text-green-600 animate-bounce-star" />
                      </div>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-2xl font-black text-gray-900 mb-3 group-hover:text-purple-600 transition-colors">
                    {challenge.title}
                  </h3>
                  <p className="text-lg text-gray-700 mb-4 font-medium leading-relaxed">
                    {challenge.description}
                  </p>

                  {/* Reward */}
                  <div className="flex items-center gap-3 mb-4">
                    <div className="px-4 py-2 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center gap-2 shadow-lg">
                      <span className="text-2xl">🍃</span>
                      <span className="text-xl font-black text-white">+{challenge.points}</span>
                    </div>
                    <div className="px-4 py-2 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center gap-2 shadow-lg">
                      <Sparkles className="w-5 h-5 text-white" />
                      <span className="text-xl font-black text-white">+{challenge.xp_reward} XP</span>
                    </div>
                  </div>

                  {/* Action Button */}
                  {!isCompleted && user && (
                    <button
                      onClick={() => handleComplete(challenge.id)}
                      disabled={isLoading}
                      className="w-full py-4 bg-gradient-to-r from-purple-600 via-pink-500 to-orange-500 text-white text-xl font-black rounded-2xl hover:shadow-2xl transform hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed relative overflow-hidden group"
                    >
                      <span className="relative z-10 flex items-center justify-center gap-2">
                        {isLoading ? (
                          <>
                            <Loader2 className="w-6 h-6 animate-spin" />
                            ¡Guardando!
                          </>
                        ) : (
                          <>
                            <CheckCircle className="w-6 h-6" />
                            ¡Lo Logré!
                          </>
                        )}
                      </span>
                      <div className="absolute inset-0 animate-shimmer" />
                    </button>
                  )}

                  {isCompleted && (
                    <div className="w-full py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xl font-black rounded-2xl flex items-center justify-center gap-3 shadow-xl">
                      <CheckCircle className="w-6 h-6" />
                      <span>¡Completado!</span>
                      <Sparkles className="w-6 h-6 animate-bounce-star" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Locked Challenges */}
      {lockedChallenges.length > 0 && (
        <div>
          <div className="flex items-center gap-3 mb-6">
            <Lock className="w-8 h-8 text-gray-400" />
            <h2 className="text-3xl font-black text-gray-500">Próximas Aventuras</h2>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {lockedChallenges.slice(0, 4).map((challenge) => (
              <div
                key={challenge.id}
                className="relative rounded-3xl overflow-hidden shadow-xl border-4 border-gray-300 bg-gray-100 opacity-60"
              >
                <div className="relative h-48 overflow-hidden grayscale">
                  <img 
                    src={challenge.image_url}
                    alt={challenge.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-white/90 backdrop-blur-sm rounded-full p-6 shadow-2xl">
                      <Lock className="w-12 h-12 text-gray-600" />
                    </div>
                  </div>

                  <div className="absolute top-4 left-4 w-16 h-16 bg-gray-400 rounded-full flex items-center justify-center text-3xl font-black text-white shadow-xl border-4 border-white">
                    {challenge.order}
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-2xl font-black text-gray-700 mb-2">
                    {challenge.title}
                  </h3>
                  <p className="text-gray-600 mb-4 font-medium">
                    {challenge.description}
                  </p>
                  <div className="px-6 py-3 bg-gray-200 rounded-2xl inline-flex items-center gap-2">
                    <Lock className="w-5 h-5 text-gray-600" />
                    <span className="text-lg font-bold text-gray-700">
                      Desbloquea en Nivel {challenge.level_required}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}