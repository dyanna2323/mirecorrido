import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { ArrowLeft, Crown } from 'lucide-react';

export default function Leaderboard() {
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list('-total_xp'),
    initialData: [],
  });

  const topUsers = users.slice(0, 50);
  const currentUserRank = users.findIndex(u => u.email === currentUser?.email) + 1;

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <div className="space-y-4">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="h-20 bg-gray-200 rounded-xl animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      {/* Header */}
      <div className="mb-6">
        <Link to={createPageUrl('Dashboard')} className="inline-flex items-center gap-2 text-purple-600 hover:text-purple-800 mb-4 transition-colors font-semibold">
          <ArrowLeft className="w-5 h-5" />
          <span>Volver al Inicio</span>
        </Link>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Tabla de Posiciones</h1>
            <p className="text-gray-600">Los mejores jugadores</p>
          </div>
          {currentUserRank > 0 && (
            <div className="text-left sm:text-right">
              <div className="text-3xl font-bold text-yellow-600">#{currentUserRank}</div>
              <p className="text-sm text-gray-600">Tu Posición</p>
            </div>
          )}
        </div>
      </div>

      {/* Top 3 Podium */}
      {topUsers.length >= 3 && (
        <div className="grid grid-cols-3 gap-4 mb-8">
          {/* 2nd Place */}
          <div className="pt-12">
            <div className="bg-white rounded-2xl border-2 border-gray-300 shadow-xl p-6 hover:scale-105 transition-all duration-500">
              <div className="text-center">
                <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-gray-400 to-gray-500 rounded-full flex items-center justify-center text-2xl font-bold text-white">
                  2
                </div>
                <h3 className="font-bold text-gray-800 mb-1 truncate">{topUsers[1]?.full_name || 'Jugador 2'}</h3>
                <p className="text-sm text-gray-600 mb-2">Nivel {topUsers[1]?.level || 1}</p>
                <p className="text-2xl font-bold text-gray-600">{(topUsers[1]?.total_xp || 0).toLocaleString()} XP</p>
              </div>
            </div>
          </div>

          {/* 1st Place */}
          <div>
            <div className="bg-white rounded-2xl border-4 border-yellow-400 shadow-2xl p-6 hover:scale-105 transition-all duration-500">
              <div className="text-center">
                <Crown className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center text-3xl font-bold text-white">
                  1
                </div>
                <h3 className="font-bold text-gray-800 mb-1 truncate">{topUsers[0]?.full_name || 'Jugador 1'}</h3>
                <p className="text-sm text-gray-600 mb-2">Nivel {topUsers[0]?.level || 1}</p>
                <p className="text-3xl font-bold text-yellow-600">{(topUsers[0]?.total_xp || 0).toLocaleString()} XP</p>
              </div>
            </div>
          </div>

          {/* 3rd Place */}
          <div className="pt-12">
            <div className="bg-white rounded-2xl border-2 border-orange-300 shadow-xl p-6 hover:scale-105 transition-all duration-500">
              <div className="text-center">
                <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-orange-600 to-orange-700 rounded-full flex items-center justify-center text-2xl font-bold text-white">
                  3
                </div>
                <h3 className="font-bold text-gray-800 mb-1 truncate">{topUsers[2]?.full_name || 'Jugador 3'}</h3>
                <p className="text-sm text-gray-600 mb-2">Nivel {topUsers[2]?.level || 1}</p>
                <p className="text-2xl font-bold text-orange-600">{(topUsers[2]?.total_xp || 0).toLocaleString()} XP</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* All Players List */}
      <div className="bg-white rounded-2xl border-2 border-purple-300 shadow-2xl overflow-hidden">
        <div className="p-6 border-b-2 border-purple-200">
          <h2 className="text-xl font-bold text-purple-700">Todos los Jugadores</h2>
        </div>
        <div className="divide-y-2 divide-purple-100">
          {topUsers.map((user, index) => (
            <div 
              key={user.id}
              className={`p-6 hover:bg-purple-50 transition-colors ${
                user.email === currentUser?.email ? 'bg-purple-100' : ''
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="text-2xl font-bold text-gray-600 w-12 text-center">
                  #{index + 1}
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold">{user.level || 1}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-gray-800 truncate">{user.full_name || 'Jugador'}</h3>
                  <p className="text-sm text-gray-600">Nivel {user.level || 1}</p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-gray-800">{(user.total_xp || 0).toLocaleString()}</p>
                  <p className="text-xs text-gray-600">XP</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}