import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { ArrowLeft, Grid, User, BookOpen, Heart, CheckSquare, Palette, Star, Check } from 'lucide-react';

export default function Achievements() {
  const [user, setUser] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('todos');
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: achievements = [] } = useQuery({
    queryKey: ['achievements'],
    queryFn: () => base44.entities.Achievement.list(),
    initialData: [],
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: () => base44.entities.UserProgress.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const unlockMutation = useMutation({
    mutationFn: async (achievementId) => {
      const achievement = achievements.find(a => a.id === achievementId);
      await base44.entities.UserProgress.create({
        user_email: user.email,
        achievement_id: achievementId,
        type: 'achievement',
        completed: true,
        progress_percentage: 100,
        completed_date: new Date().toISOString()
      });
      
      const newXP = (user.total_xp || 0) + achievement.xp_reward;
      const newLevel = Math.floor(newXP / 1000) + 1;
      await base44.auth.updateMe({ total_xp: newXP, level: newLevel });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userProgress'] });
      base44.auth.me().then(setUser);
    },
  });

  const filteredAchievements = selectedCategory === 'todos' 
    ? achievements 
    : achievements.filter(a => a.category === selectedCategory);

  const categories = [
    { id: 'todos', name: 'Todos', icon: Grid },
    { id: 'social', name: 'Social', icon: User },
    { id: 'aprendizaje', name: 'Aprendizaje', icon: BookOpen },
    { id: 'movimiento', name: 'Movimiento', icon: Heart },
    { id: 'tareas', name: 'Tareas', icon: CheckSquare },
    { id: 'creatividad', name: 'Creatividad', icon: Palette }
  ];

  const rarityColors = {
    comun: { bg: 'from-gray-500 to-gray-600', border: 'border-gray-400/30' },
    raro: { bg: 'from-blue-500 to-blue-600', border: 'border-blue-400/30' },
    epico: { bg: 'from-purple-500 to-purple-600', border: 'border-purple-400/30' },
    legendario: { bg: 'from-amber-500 to-amber-600', border: 'border-amber-400/30' }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8">
      {/* Header */}
      <div className="mb-6">
        <Link to={createPageUrl('Dashboard')} className="inline-flex items-center gap-2 text-purple-600 hover:text-purple-800 mb-4 transition-colors font-semibold">
          <ArrowLeft className="w-5 h-5" />
          <span>Volver al Inicio</span>
        </Link>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Logros</h1>
            <p className="text-gray-600">Desbloquea insignias y gana puntos</p>
          </div>
          <div className="text-left sm:text-right">
            <div className="text-3xl font-bold text-purple-600">{userProgress.filter(p => p.type === 'achievement' && p.completed).length}</div>
            <p className="text-sm text-gray-600">Desbloqueados 🏆</p>
          </div>
        </div>
      </div>

      {/* Category Filters */}
      <div className="mb-6">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map(cat => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl backdrop-blur-xl border-2 transition-all duration-300 whitespace-nowrap shrink-0 ${
                  selectedCategory === cat.id
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 border-purple-300 text-white scale-105'
                    : 'bg-white border-purple-200 text-gray-700 hover:bg-gray-50 hover:scale-105'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-sm font-semibold">{cat.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredAchievements.map((achievement) => {
          const isUnlocked = userProgress.some(p => p.achievement_id === achievement.id && p.completed);
          
          const rarity = achievement.rarity || 'comun';
          const colors = rarityColors[rarity] || rarityColors['comun'];

          return (
            <div 
              key={achievement.id}
              className={`group bg-white rounded-2xl border-2 shadow-xl p-6 transition-all duration-500 hover:scale-105 ${
                isUnlocked ? colors.border : 'border-gray-200'
              }`}
            >
              {achievement.image_url && (
                <div className="w-full h-40 mb-4 rounded-xl overflow-hidden">
                  <img 
                    src={achievement.image_url} 
                    alt={achievement.title}
                    className={`w-full h-full object-cover ${isUnlocked ? '' : 'opacity-50 grayscale'}`}
                  />
                </div>
              )}
              
              <div className={`w-16 h-16 bg-gradient-to-br ${colors.bg} rounded-xl flex items-center justify-center mb-4 mx-auto ${
                isUnlocked ? '' : 'opacity-50 grayscale'
              }`}>
                <Star className="w-8 h-8 text-white" />
              </div>
              
              <h3 className="font-bold text-gray-800 mb-2 text-center">{achievement.title}</h3>
              <p className="text-sm text-gray-600 mb-4 text-center">{achievement.description}</p>
              
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs text-gray-500 capitalize">{rarity}</span>
                <span className="text-sm font-bold text-yellow-600">+{achievement.xp_reward} XP</span>
              </div>

              {!isUnlocked && user && (
                <button
                  onClick={() => unlockMutation.mutate(achievement.id)}
                  disabled={unlockMutation.isLoading}
                  className="w-full py-2.5 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl text-sm font-semibold text-white hover:from-purple-600 hover:to-pink-600 transition-all duration-300 disabled:opacity-50"
                >
                  {unlockMutation.isLoading ? 'Desbloqueando...' : 'Desbloquear Ahora'}
                </button>
              )}

              {isUnlocked && (
                <div className="flex items-center justify-center gap-2 py-2.5 bg-green-100 rounded-xl border-2 border-green-400">
                  <Check className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-semibold text-green-600">¡Desbloqueado!</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {filteredAchievements.length === 0 && (
        <div className="text-center py-20">
          <Star className="w-24 h-24 text-gray-400 mx-auto mb-4" />
          <p className="text-2xl font-bold text-gray-600">¡Pronto habrá más logros!</p>
        </div>
      )}
    </div>
  );
}