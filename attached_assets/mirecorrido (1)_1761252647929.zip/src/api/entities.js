import { base44 } from './base44Client';


export const Achievement = base44.entities.Achievement;

export const Challenge = base44.entities.Challenge;

export const UserProgress = base44.entities.UserProgress;

export const Reward = base44.entities.Reward;

export const UserReward = base44.entities.UserReward;

export const Question = base44.entities.Question;

export const ChallengeLog = base44.entities.ChallengeLog;

export const Medal = base44.entities.Medal;

export const UserMedal = base44.entities.UserMedal;



// auth sdk:
export const User = base44.auth;