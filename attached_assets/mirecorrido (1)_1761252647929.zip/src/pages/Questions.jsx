import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { ArrowLeft, Brain, Trophy, Star, CheckCircle, XCircle, Sparkles, Zap } from 'lucide-react';
import { useToast } from '../components/ToastContainer';
import { Button } from '@/components/ui/button';

export default function Questions() {
  const [user, setUser] = useState(null);
  const [selectedSubject, setSelectedSubject] = useState('maths');
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [usedQuestionIds, setUsedQuestionIds] = useState([]);
  const queryClient = useQueryClient();
  const { showToast } = useToast();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: questions = [] } = useQuery({
    queryKey: ['questions', selectedSubject],
    queryFn: () => base44.entities.Question.filter({ subject: selectedSubject }),
    initialData: [],
  });

  const answerMutation = useMutation({
    mutationFn: async ({ isCorrect }) => {
      const pointsEarned = isCorrect ? 15 : 0;
      
      if (isCorrect) {
        const newXP = (user.total_xp || 0) + pointsEarned;
        const newGumLeaves = (user.gum_leaves || 0) + pointsEarned;
        const newLevel = Math.floor(newXP / 1000) + 1;
        
        const subjectLevel = selectedSubject === 'maths' ? 'level_maths' : 'level_english';
        const currentSubjectLevel = user[subjectLevel] || 1;
        const newSubjectLevel = Math.floor(newXP / 500) + 1;
        
        await base44.auth.updateMe({ 
          total_xp: newXP, 
          level: newLevel,
          gum_leaves: newGumLeaves,
          [subjectLevel]: Math.max(currentSubjectLevel, newSubjectLevel)
        });
      }
    },
    onSuccess: (_, { isCorrect }) => {
      queryClient.invalidateQueries();
      base44.auth.me().then(setUser);
      if (isCorrect) {
        showToast('¡Correcto! +15 puntos 🎉', 'success');
      } else {
        showToast('Incorrecto. ¡Sigue intentando! 💪', 'error');
      }
    },
  });

  const handleAnswer = (answer) => {
    setSelectedAnswer(answer);
    const correct = answer === currentQuestion.correct_answer;
    setIsCorrect(correct);
    setShowResult(true);
    answerMutation.mutate({ isCorrect: correct });
  };

  const handleNextQuestion = () => {
    // Buscar una pregunta que NO hayamos usado
    const availableQuestions = questions.filter(q => !usedQuestionIds.includes(q.id));
    
    if (availableQuestions.length === 0) {
      // Si ya usamos todas, resetear el array
      setUsedQuestionIds([]);
      const randomIndex = Math.floor(Math.random() * questions.length);
      const nextQ = questions[randomIndex];
      setCurrentQuestion(nextQ);
      setUsedQuestionIds([nextQ.id]);
    } else {
      // Elegir aleatoriamente de las disponibles
      const randomIndex = Math.floor(Math.random() * availableQuestions.length);
      const nextQ = availableQuestions[randomIndex];
      setCurrentQuestion(nextQ);
      setUsedQuestionIds(prev => [...prev, nextQ.id]);
    }
    
    setSelectedAnswer(null);
    setShowResult(false);
  };

  useEffect(() => {
    if (questions.length > 0 && !currentQuestion) {
      const randomIndex = Math.floor(Math.random() * questions.length);
      const firstQ = questions[randomIndex];
      setCurrentQuestion(firstQ);
      setUsedQuestionIds([firstQ.id]);
    }
  }, [questions, currentQuestion]);

  useEffect(() => {
    // Reset cuando cambiamos de materia
    setCurrentQuestion(null);
    setUsedQuestionIds([]);
    setShowResult(false);
    setSelectedAnswer(null);
  }, [selectedSubject]);

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto p-4 md:p-8">
        <div className="h-96 bg-gray-200 rounded-xl animate-pulse" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8">
      <style>{`
        @keyframes bounce-star {
          0%, 100% { transform: translateY(0) scale(1); }
          50% { transform: translateY(-10px) scale(1.2); }
        }
        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 20px rgba(168, 85, 247, 0.4); }
          50% { box-shadow: 0 0 30px rgba(168, 85, 247, 0.6); }
        }
        .animate-bounce-star { animation: bounce-star 1s ease-in-out infinite; }
        .animate-pulse-glow { animation: pulse-glow 2s ease-in-out infinite; }
      `}</style>

      <Link to={createPageUrl('Dashboard')} className="inline-flex items-center gap-2 text-purple-600 hover:text-purple-800 mb-6 transition-colors font-semibold">
        <ArrowLeft className="w-5 h-5" />
        <span>Volver al Inicio</span>
      </Link>

      <div className="flex items-center gap-4 mb-8">
        <div className="p-4 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl shadow-lg animate-pulse-glow">
          <Brain className="w-12 h-12 text-white" />
        </div>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Preguntas Educativas</h1>
          <p className="text-gray-600">Responde y gana 15 puntos por cada respuesta correcta</p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-yellow-600">{user.gum_leaves || 0}</div>
          <p className="text-sm text-gray-600">🍃 Hojas</p>
        </div>
      </div>

      {/* Subject Selector */}
      <div className="flex gap-3 mb-8">
        <button
          onClick={() => setSelectedSubject('maths')}
          className={`flex-1 py-4 rounded-xl font-bold transition-all duration-300 ${
            selectedSubject === 'maths'
              ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-lg scale-105'
              : 'bg-white text-gray-700 border-2 border-gray-200 hover:scale-105'
          }`}
        >
          🧮 Matemáticas
          <div className="text-sm font-normal mt-1">Nivel {user.level_maths || 1}</div>
        </button>
        <button
          onClick={() => setSelectedSubject('english')}
          className={`flex-1 py-4 rounded-xl font-bold transition-all duration-300 ${
            selectedSubject === 'english'
              ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg scale-105'
              : 'bg-white text-gray-700 border-2 border-gray-200 hover:scale-105'
          }`}
        >
          📚 Inglés
          <div className="text-sm font-normal mt-1">Nivel {user.level_english || 1}</div>
        </button>
      </div>

      {/* Question Card */}
      {currentQuestion ? (
        <div className="bg-white rounded-2xl shadow-xl p-8 border-2 border-purple-200">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Star className="w-6 h-6 text-yellow-500 animate-bounce-star" />
              <span className="text-sm font-semibold text-gray-600">
                Dificultad: {currentQuestion.difficulty}/10
              </span>
            </div>
            {!showResult && (
              <div className="px-4 py-2 bg-purple-100 rounded-lg text-purple-700 font-semibold text-sm flex items-center gap-2">
                <Zap className="w-4 h-4" />
                +15 puntos
              </div>
            )}
          </div>

          {currentQuestion.question_image && (
            <div className="mb-6 rounded-xl overflow-hidden">
              <img 
                src={currentQuestion.question_image}
                alt="Pregunta"
                className="w-full h-64 object-cover"
              />
            </div>
          )}

          <h3 className="text-2xl font-bold text-gray-900 mb-8">{currentQuestion.question_text}</h3>

          {!showResult ? (
            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswer(option)}
                  disabled={answerMutation.isLoading}
                  className="w-full p-4 rounded-xl border-2 border-gray-200 hover:border-purple-400 hover:bg-purple-50 transition-all duration-300 text-left font-semibold text-gray-800 hover:scale-105 disabled:opacity-50"
                >
                  {String.fromCharCode(65 + index)}. {option}
                </button>
              ))}
            </div>
          ) : (
            <div className="space-y-6">
              <div className={`p-6 rounded-xl ${isCorrect ? 'bg-green-50 border-2 border-green-400' : 'bg-red-50 border-2 border-red-400'}`}>
                <div className="flex items-center gap-3 mb-3">
                  {isCorrect ? (
                    <>
                      <CheckCircle className="w-8 h-8 text-green-600" />
                      <h4 className="text-2xl font-bold text-green-600">¡Correcto!</h4>
                      <Sparkles className="w-6 h-6 text-yellow-500 animate-bounce-star" />
                    </>
                  ) : (
                    <>
                      <XCircle className="w-8 h-8 text-red-600" />
                      <h4 className="text-2xl font-bold text-red-600">Incorrecto</h4>
                    </>
                  )}
                </div>
                {!isCorrect && (
                  <p className="text-gray-700">
                    La respuesta correcta es: <span className="font-bold">{currentQuestion.correct_answer}</span>
                  </p>
                )}
                {isCorrect && (
                  <p className="text-green-700 font-semibold">¡Has ganado 15 hojas de eucalipto! 🍃</p>
                )}
              </div>

              <Button
                onClick={handleNextQuestion}
                className="w-full py-6 text-lg bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                Siguiente Pregunta →
              </Button>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-xl p-12 text-center border-2 border-gray-200">
          <Brain className="w-24 h-24 text-gray-400 mx-auto mb-6" />
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            No hay preguntas disponibles
          </h3>
          <p className="text-gray-600 mb-6">
            Las preguntas de {selectedSubject === 'maths' ? 'matemáticas' : 'inglés'} se están preparando
          </p>
        </div>
      )}
    </div>
  );
}