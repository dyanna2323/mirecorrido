import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { ArrowLeft, Gamepad2, Users, Trophy, Lock, Sparkles, Play } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

export default function Games() {
  const [user, setUser] = useState(null);
  const [selectedGame, setSelectedGame] = useState(null);
  const [showGameDialog, setShowGameDialog] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: challenges = [] } = useQuery({
    queryKey: ['challenges'],
    queryFn: () => base44.entities.Challenge.list(),
    initialData: [],
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: () => base44.entities.UserProgress.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const totalChallengePoints = userProgress
    .filter(p => p.type === 'challenge' && p.completed)
    .reduce((total, p) => {
      const challenge = challenges.find(c => c.id === p.achievement_id);
      return total + (challenge?.xp_reward || 0);
    }, 0);

  const gamesUnlocked = totalChallengePoints >= 1000;

  const games = [
    {
      id: 1,
      title: "Tres en Raya",
      description: "Juega con un amigo o familiar al clásico juego de tres en raya",
      image: "https://images.unsplash.com/photo-1611996575749-79a3a250f948?w=800&q=80",
      players: "2 jugadores",
      color: "from-blue-500 to-cyan-500",
      instructions: "Dos jugadores se turnan para colocar sus marcas (X u O) en una cuadrícula de 3x3. El primero en conseguir tres en línea horizontal, vertical o diagonal gana."
    },
    {
      id: 2,
      title: "Memoria de Parejas",
      description: "Encuentra las parejas de cartas con un compañero",
      image: "https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=800&q=80",
      players: "2 jugadores",
      color: "from-purple-500 to-pink-500",
      instructions: "Coloca las cartas boca abajo. Los jugadores se turnan para voltear dos cartas. Si coinciden, el jugador se las queda. Gana quien tenga más parejas al final."
    },
    {
      id: 3,
      title: "Dibuja y Adivina",
      description: "Uno dibuja y el otro adivina qué es",
      image: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=800&q=80",
      players: "2 jugadores",
      color: "from-yellow-500 to-orange-500",
      instructions: "Un jugador dibuja una palabra secreta mientras el otro intenta adivinar. Tienen 60 segundos. Luego intercambian roles."
    },
    {
      id: 4,
      title: "Carrera de Preguntas",
      description: "Respondan preguntas por turnos y gana quien llegue primero",
      image: "https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?w=800&q=80",
      players: "2 jugadores",
      color: "from-green-500 to-emerald-500",
      instructions: "Los jugadores responden preguntas de conocimiento general por turnos. Cada respuesta correcta los hace avanzar en el tablero. Primero en llegar a la meta gana."
    }
  ];

  const handleGameClick = (game) => {
    setSelectedGame(game);
    setShowGameDialog(true);
  };

  return (
    <>
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <Link to={createPageUrl('Dashboard')} className="inline-flex items-center gap-2 text-purple-600 hover:text-purple-800 mb-6 transition-colors font-semibold">
          <ArrowLeft className="w-5 h-5" />
          <span>Volver al Inicio</span>
        </Link>

        <div className="flex items-center gap-4 mb-8">
          <div className="p-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl shadow-lg">
            <Gamepad2 className="w-12 h-12 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              Zona de Juegos
              <Sparkles className="w-8 h-8 text-yellow-500" />
            </h1>
            <p className="text-gray-600">Diviértete jugando con amigos o familia</p>
          </div>
        </div>

        {!gamesUnlocked ? (
          <div className="bg-white rounded-2xl shadow-xl p-12 text-center border-4 border-yellow-400">
            <Lock className="w-32 h-32 text-yellow-500 mx-auto mb-6" />
            <h2 className="text-4xl font-bold text-gray-900 mb-4">¡Casi lo tienes!</h2>
            <p className="text-2xl text-gray-600 mb-6">
              Completa desafíos para desbloquear esta zona especial
            </p>
            <div className="bg-gradient-to-r from-purple-100 to-pink-100 rounded-2xl p-6 max-w-md mx-auto">
              <div className="text-6xl font-bold text-purple-600 mb-2">
                {totalChallengePoints} / 1000
              </div>
              <div className="text-base text-gray-600 font-semibold mb-4">puntos de desafíos</div>
              <div className="h-6 bg-white rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-1000"
                  style={{width: `${(totalChallengePoints / 1000) * 100}%`}}
                />
              </div>
              <p className="text-xl font-bold text-purple-600 mt-4">
                ¡Te faltan solo {1000 - totalChallengePoints} puntos!
              </p>
            </div>
            <Link to={createPageUrl('Challenges')} className="inline-block mt-8">
              <Button className="px-8 py-6 text-lg bg-purple-600 hover:bg-purple-700">
                ¡Ir a Desafíos!
              </Button>
            </Link>
          </div>
        ) : (
          <>
            <div className="bg-gradient-to-r from-green-400 to-emerald-400 rounded-2xl p-6 mb-8 shadow-xl text-center">
              <Trophy className="w-16 h-16 text-white mx-auto mb-3" />
              <h2 className="text-3xl font-bold text-white mb-2">¡Felicidades, Campeón!</h2>
              <p className="text-lg text-white font-semibold">Has desbloqueado la zona de juegos</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
              {games.map((game) => (
                <div 
                  key={game.id}
                  className="group"
                >
                  <div className={`rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 transform border-4 border-white/50 bg-gradient-to-br ${game.color}`}>
                    <div className="relative h-56 overflow-hidden">
                      <img 
                        src={game.image}
                        alt={game.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                      <div className="absolute bottom-4 left-4 right-4">
                        <h3 className="text-2xl font-bold text-white mb-1">{game.title}</h3>
                        <div className="flex items-center gap-2 text-white/90">
                          <Users className="w-5 h-5" />
                          <span>{game.players}</span>
                        </div>
                      </div>
                    </div>
                    <div className="bg-white/95 backdrop-blur-xl p-6">
                      <p className="text-base text-gray-700 mb-4 leading-relaxed">{game.description}</p>
                      <Button
                        onClick={() => handleGameClick(game)}
                        className={`w-full py-4 bg-gradient-to-r ${game.color} text-white font-bold hover:scale-105 transition-transform shadow-lg`}
                      >
                        <Play className="w-6 h-6 mr-2" />
                        Ver Instrucciones
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Game Instructions Dialog */}
      <Dialog open={showGameDialog} onOpenChange={setShowGameDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedGame?.title}</DialogTitle>
            <DialogDescription className="text-base">
              {selectedGame?.description}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {selectedGame?.image && (
              <img 
                src={selectedGame.image}
                alt={selectedGame.title}
                className="w-full h-48 object-cover rounded-lg"
              />
            )}
            <div>
              <h4 className="font-semibold text-lg mb-2">Cómo jugar:</h4>
              <p className="text-gray-700">{selectedGame?.instructions}</p>
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <Users className="w-5 h-5" />
              <span className="font-medium">{selectedGame?.players}</span>
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <Button 
              onClick={() => setShowGameDialog(false)}
              variant="outline"
              className="flex-1"
            >
              Cerrar
            </Button>
            <Button 
              onClick={() => {
                setShowGameDialog(false);
              }}
              className={`flex-1 bg-gradient-to-r ${selectedGame?.color} text-white`}
            >
              <Play className="w-5 h-5 mr-2" />
              Jugar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}